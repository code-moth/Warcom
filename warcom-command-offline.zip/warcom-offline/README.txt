WARCOM COMMAND — offline runtime
=================================

This is a self-contained build of Warcom Command, the War Law mass-combat
assistant. It needs no internet connection and no install step.

HOW TO RUN IT
--------------
Just open index.html in any modern browser (Chrome, Firefox, Edge, Safari):

  - Double-click index.html, or
  - Drag it into an open browser window, or
  - Right-click -> Open with -> your browser

Everything works from the file directly — no local server required.

WHAT'S INCLUDED
-----------------
  index.html           the app shell and styling
  bundle.js             the full application (engine + UI), pre-bundled
  vendor-jszip.min.js   JSZip v3.10.1, unmodified upstream build, used only
                         for the legacy .UNT/.BTL zip export/import feature
                         (MIT/GPL dual-licensed, (c) Stuart Knightley)

WHAT'S DIFFERENT FROM THE HOSTED VERSION
-------------------------------------------
  - Fonts: this build uses your system's serif/sans/monospace fonts
    instead of downloading Fraunces / Public Sans / IBM Plex Mono from
    Google Fonts. Everything still renders correctly, just with different
    typefaces.
  - Saving files: "Save battle (.json)" and the legacy .UNT/.BTL exports
    use a plain browser download here, instead of the claude.ai artifact
    platform's save dialog. Your browser's normal download behavior and
    download folder apply.
  - Autosave: the app still autosaves your in-progress battle to this
    browser's local storage as you work, exactly as the hosted version
    does. That storage is local to whichever browser and machine you're
    using — it doesn't sync anywhere.

Everything else — the combat math, the roster, the attack queue, the
battle log, the weapons reference, and the legacy file formats — is
identical to the hosted version. Combat resolution has been verified
attack-by-attack against the original compiled DOS source.

SOURCE
-------
Warcom Command is a from-scratch web port of Warcom by David Eubanks
(GPL-3.0): https://github.com/code-moth/Warcom
